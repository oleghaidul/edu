CKEDITOR.plugins.setLang('attachment', 'uk',
{
  attachment : 
  {
    title : "Вставити файл",
    url: "URL",
    name: "Назва",
    button : "Вставити"
  }
});
