CKEDITOR.plugins.setLang('embed', 'en',
{
  embed : 
  {
    title : "Paste embed",
    button : "Paste embed",
    pasteMsg : "Please, paste embed-code from Youtube, Myspace, Flickr and others sources into rectangle, using the keyboard (Ctrl + V), and click OK."
  }
});
